global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6282218279084']
global.botname = 'Rxhl Bot'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Rxhl Official"
global.sticker2 = "🌜"